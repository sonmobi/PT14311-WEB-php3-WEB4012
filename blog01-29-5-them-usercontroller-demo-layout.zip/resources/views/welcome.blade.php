<h1>
    Hello
</h1>

<?php
    $name = "Son";
?>

{{$name}}



